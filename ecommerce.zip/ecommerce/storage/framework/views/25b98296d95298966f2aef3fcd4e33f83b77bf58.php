
<?php $__env->startSection('page_title','Manage Size'); ?>
<?php $__env->startSection('container'); ?>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mx-auto h-100">
                        <li class="nav-item">
                            <a class="nav-link " href="http://127.0.0.1:8000/admin/dashboard/">
                                <i class="fas fa-tachometer-alt"></i>
                                Dashboard
                                <span class="sr-only">(current)</span>
                            </a>
                        </li>
                        </li>
                        

                        <li class="nav-item">
                            <a class="nav-link" href="http://127.0.0.1:8000/admin/category/">
                                <i class="fa fa-list-alt"></i>
                                <span>
                                Category
                                <span class="sr-only">(current)</span>
                                </span>
                            </a>
                        
                        </li>
                        
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="http://127.0.0.1:8000/admin/coupon/">
                                <i class="fas fa-tag"></i>
                                <span>
                                Coupon
                                </span>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link active" href="http://127.0.0.1:8000/admin/size/">
                                <i class="fas fa-tag"></i>
                                <span>
                                Size
                                </span>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="http://127.0.0.1:8000/admin/color/">
                                <i class="fas fa-paint-roller"></i>
                                <span>
                                Color
                                </span>
                            </a>
                        </li>
                       

                        <li class="nav-item">
                            <a class="nav-link" href="products.html">
                                <i class="fas fa-shopping-cart"></i>
                                <span>
                                Products
                                </span>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="accounts.html">
                                <i class="far fa-user"></i>
                                Accounts
                            </a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-cog"></i>
                                <span>
                                    Settings <i class="fas fa-angle-down"></i>
                                </span>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="#">Profile</a>
                                <a class="dropdown-item" href="#">Billing</a>
                                <a class="dropdown-item" href="#">Customize</a>
                            </div>
                        </li>
                    </ul>
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link d-block" href="login.html">
                                Admin, <b>Logout</b>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            </nav>
        <div class="container">
            <div class="row">
                <div class="col">
                    <p class="text-white mt-5 mb-5">Welcome back, <b>Admin</b></p>
                </div>
                </div>
        
        <div class="row">
        
            <div class="col">
            <div class="heading">
            <h1 class="text-white"><b>Manage Size</b></h1>
            <a href="<?php echo e(url('admin/size')); ?>">
            <button type="button" class="btn btn-success">Back</button>
            </a>
            </div>
          
            <div class="container-fluid">
        
        
        <form action="<?php echo e(route('size.manage_size_process')); ?>" method="post">
          <?php echo csrf_field(); ?>          
		<div class="form-group has-success has-feedback">
  <label class="control-label" id="size" for="size">Size</label>
  <input type="text" class="form-control" value="<?php echo e($size); ?>"name="size" aria-describedby="usernameStatus" required>
  <span class="glyphicon glyphicon-ok form-control-feedback" aria-hidden="true"></span> 
  <?php $__errorArgs = ['size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <?php echo e($message); ?>

  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>



<button type="submit" class="btn btn-success">Submit</button>
</div>
<input type="hidden" name="id" value="<?php echo e($id); ?>"/>
</form>


                
            
            
                    </div>

            
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>





<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ecommerce\resources\views/admin/manage_size.blade.php ENDPATH**/ ?>