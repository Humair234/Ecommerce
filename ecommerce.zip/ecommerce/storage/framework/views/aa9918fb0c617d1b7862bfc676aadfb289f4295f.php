
<?php $__env->startSection('page_title','Coupon'); ?>
<?php $__env->startSection('container'); ?>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mx-auto h-100">
                        <li class="nav-item">
                            <a class="nav-link " href="http://127.0.0.1:8000/admin/dashboard/">
                                <i class="fas fa-tachometer-alt"></i>
                                Dashboard
                                <span class="sr-only">(current)</span>
                            </a>
                        </li>
                        </li>
                        

                        <li class="nav-item">
                            <a class="nav-link" href="http://127.0.0.1:8000/admin/category/">
                                <i class="fa fa-list-alt"></i>
                                <span>
                                Category
                                <span class="sr-only">(current)</span>
                                </span>
                            </a>
                        
                        </li>
                        
                        </li>
                             
                        <li class="nav-item">
                            <a class="nav-link active" href="http://127.0.0.1:8000/admin/coupon/">
                                <i class="fas fa-tag"></i>
                                <span>
                                Coupon
                                </span>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="http://127.0.0.1:8000/admin/size/">
                                <i class="fas fa-tag"></i>
                                <span>
                                Size
                                </span>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="http://127.0.0.1:8000/admin/color/">
                                <i class="fas fa-paint-roller"></i>
                                <span>
                                Color
                                </span>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="http://127.0.0.1:8000/admin/product/">
                                <i class="fas fa-shopping-cart"></i>
                                <span>
                                Products
                                </span>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="accounts.html">
                                <i class="far fa-user"></i>
                                Accounts
                            </a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-cog"></i>
                                <span>
                                    Settings <i class="fas fa-angle-down"></i>
                                </span>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="#">Profile</a>
                                <a class="dropdown-item" href="#">Billing</a>
                                <a class="dropdown-item" href="#">Customize</a>
                            </div>
                        </li>
                    </ul>
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link d-block" href="http://127.0.0.1:8000/admin/logout">
                                Admin, <b>Logout</b>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            </nav>
        <div class="container">
            <div class="row">
                <div class="col">
                    <p class="text-white mt-5 mb-5">Welcome back, <b>Admin</b></p>
                </div>
                </div>

                <h3><b><?php echo e(session('message')); ?></b></h3>
        
        <div class="row">
        
            <div class="col">
            <div class="heading">
            <h1 class="text-white"><b>Coupon</b></h1>
            <a href="http://127.0.0.1:8000/admin/coupon/manage_coupon">
            <button type="button" class="btn btn-success">Add Coupon</button>
            </a>
            </div>
          

            
            <div class="col-12 tm-block-col">
                    <div class="tm-bg-primary-dark tm-block tm-block-taller tm-block-scroll">
                        <h2 class="tm-block-title">Coupon List</h2>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">ID.</th>
                                    <th scope="col">Title</th>
                                    <th scope="col">Code</th>
                                    <th scope="col">Value</th>
                                    <th scope="col">Action</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><b><?php echo e($list->id); ?></b></th>
                                    <td>
                                             <?php echo e($list->title); ?>

                                    </td>
                                    <td><b><?php echo e($list->code); ?></b></td>
                                    <td><?php echo e($list->value); ?><b>
                                    <td><b>
                                   <a href="<?php echo e(url('admin/coupon/delete/')); ?>/<?php echo e($list->id); ?>"> <button type="button" class="btn btn-danger">Delete</button></a>
                                   <a href="<?php echo e(url('admin/coupon/manage_coupon/')); ?>/<?php echo e($list->id); ?>"> <button type="button" class="btn btn-success">Edit</button></a>
                                   <?php if($list->status==1): ?>
                                   <a href="<?php echo e(url('admin/coupon/status/0')); ?>/<?php echo e($list->id); ?>"> <button type="button" class="btn btn-info">Active</button></a>
                                   <?php elseif($list->status==0): ?> 
                                   <a href="<?php echo e(url('admin/coupon/status/1')); ?>/<?php echo e($list->id); ?>"> <button type="button" class="btn btn-warning">Deactive</button></a> 
                                   <?php endif; ?> 
                                    </b></td>
                                    
                                </tr>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>





<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ecommerce\resources\views/admin/coupon.blade.php ENDPATH**/ ?>