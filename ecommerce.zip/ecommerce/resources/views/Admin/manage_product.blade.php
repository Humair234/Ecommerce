@extends('admin/layout')
@section('page_title','Manage Product')
@section('container')


@if($id>0)
{{$image_required=""}}
@else
{{$image_required="required"}}
@endif

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mx-auto h-100">
                        <li class="nav-item">
                            <a class="nav-link " href="http://127.0.0.1:8000/admin/dashboard/">
                                <i class="fas fa-tachometer-alt"></i>
                                Dashboard
                                <span class="sr-only">(current)</span>
                            </a>
                        </li>
                        </li>
                        

                        <li class="nav-item">
                            <a class="nav-link" href="http://127.0.0.1:8000/admin/category/">
                                <i class="fa fa-list-alt"></i>
                                <span>
                                Category
                                <span class="sr-only">(current)</span>
                                </span>
                            </a>
                        
                        </li>
                        
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="http://127.0.0.1:8000/admin/coupon/">
                                <i class="fas fa-tag"></i>
                                <span>
                                Coupon
                                </span>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="http://127.0.0.1:8000/admin/size/">
                                <i class="fas fa-tag"></i>
                                <span>
                                Size
                                </span>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="http://127.0.0.1:8000/admin/color/">
                                <i class="fas fa-paint-roller"></i>
                                <span>
                                Color
                                </span>
                            </a>
                        </li>
                    
                       

                        <li class="nav-item">
                            <a class="nav-link active" href="http://127.0.0.1:8000/admin/product/">
                                <i class="fas fa-shopping-cart"></i>
                                <span>
                                Products
                                </span>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="accounts.html">
                                <i class="far fa-user"></i>
                                Accounts
                            </a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-cog"></i>
                                <span>
                                    Settings <i class="fas fa-angle-down"></i>
                                </span>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="#">Profile</a>
                                <a class="dropdown-item" href="#">Billing</a>
                                <a class="dropdown-item" href="#">Customize</a>
                            </div>
                        </li>
                    </ul>
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link d-block" href="login.html">
                                Admin, <b>Logout</b>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            </nav>
        <div class="container">
            <div class="row">
                <div class="col">
                    <p class="text-white mt-5 mb-5">Welcome back, <b>Admin</b></p>
                </div>
                </div>
        
        <div class="row">
        
            <div class="col">
            <div class="heading">
            <h1 class="text-white"><b>Manage Product</b></h1>
            <a href="{{url('admin/product')}}">
            <button type="button" class="btn btn-success">Back</button>
            </a>
            </div>
          
            <div class="container-fluid">
        
        
        <form action="{{route('product.manage_product_process')}}" method="post" enctype="multipart/form-data">
          @csrf          
		<div class="form-group has-success has-feedback">
  <label class="control-label" id="name" for="name">Name</label>
  <input type="text" class="form-control" value="{{$name}}"name="name" aria-describedby="usernameStatus" required>
  <span class="glyphicon glyphicon-ok form-control-feedback" aria-hidden="true"></span> 
  @error('name')
  {{$message}}
  @enderror
</div>
<div class="form-group has-warning has-feedback">
  <label class="control-label" for="slug">Slug</label>
  <input type="text" class="form-control" value="{{$slug}}" name="slug" id="slug" aria-describedby="passwordStatus" required>
  <span class="glyphicon glyphicon-warning-sign form-control-feedback" aria-hidden="true"></span>
  @error('slug')
  <b> {{$message}}</b>
  @enderror
</div>

<div class="form-group has-warning has-feedback">
  <label class="control-label" for="image">Image</label>
  <input type="file" class="form-control" name="image" id="image" aria-describedby="passwordStatus" {{$image_required}}>
  <span class="glyphicon glyphicon-warning-sign form-control-feedback" aria-hidden="true"></span>
  @error('image')
  <b> {{$message}}</b>
  @enderror
</div>


<div class="form-group has-warning has-feedback">
  <label class="control-label" for="category_id">Category</label>
  <select type="text" class="form-control" name="category_id" id="category_id" aria-describedby="passwordStatus" required>
    <option value="">Select Categories</option>
     @foreach($category as $list)
     @if($category_id==$list->id)
     <option selected value="{{$list->id}}">
      @else   
     <option value="{{$list->id}}">
    @endif
    {{$list->category_name}}</option>
    @endforeach
</select>
  
 
</div>

<div class="form-group has-warning has-feedback">
  <label class="control-label" for="brand">Brand</label>
  <input type="text" class="form-control" value="{{$brand}}" name="brand" id="brand" aria-describedby="passwordStatus" required>
  <span class="glyphicon glyphicon-warning-sign form-control-feedback" aria-hidden="true"></span>
 
</div>

<div class="form-group has-warning has-feedback">
  <label class="control-label" for="model">Model</label>
  <input type="text" class="form-control" value="{{$model}}" name="model" id="model" aria-describedby="passwordStatus" required>
  <span class="glyphicon glyphicon-warning-sign form-control-feedback" aria-hidden="true"></span>
 
</div>

<div class="form-group has-warning has-feedback">
  <label class="control-label" for="short_desc">Short Description</label>
  <textarea type="text" class="form-control" name="short_desc" id="short_desc" aria-describedby="passwordStatus" required>
  {{$short_desc}}</textarea>
  
 
</div>


<div class="form-group has-warning has-feedback">
  <label class="control-label" for="desc">Description</label>
  <textarea type="text" class="form-control" name="desc" id="desc" aria-describedby="passwordStatus" required>
  {{$desc}}</textarea>
</div>

<div class="form-group has-warning has-feedback">
  <label class="control-label" for="keywords">Keywords</label>
  <textarea type="text" class="form-control" name="keywords" id="keywords" aria-describedby="passwordStatus" required>
  {{$keywords}}</textarea>
</div>

<div class="form-group has-warning has-feedback">
  <label class="control-label" for="technical_specification">Technical Specification</label>
  <textarea type="text" class="form-control" name="technical_specification" id="technical_specification" aria-describedby="passwordStatus" required>
  {{$technical_specification}}</textarea>
</div>

<div class="form-group has-warning has-feedback">
  <label class="control-label" for="uses">Uses</label>
  <textarea type="text" class="form-control" name="uses" id="uses" aria-describedby="passwordStatus" required>
  {{$uses}}</textarea>
</div>

<div class="form-group has-warning has-feedback">
  <label class="control-label" for="warranty">Warranty</label>
  <textarea type="text" class="form-control" name="warranty" id="warranty" aria-describedby="passwordStatus" required>
  {{$warranty}}</textarea>
</div>


<button type="submit" class="btn btn-success">Submit</button>
</div>
<input type="hidden" name="id" value="{{$id}}"/>
</form>


                
            
            
                    </div>

            
                </div>
            </div>
        </div>

@endsection




